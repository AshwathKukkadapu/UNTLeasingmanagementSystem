<!DOCTYPE html>
<html lang="en">

<head>
    <!--<meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">-->

    <!-- Bootstrap CSS -->
    <!--<link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/all.min.css">
    <link rel="stylesheet" href="assets/css/mylogin.css">
    <title>Guards Portal</title>
    -->
      <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">  
                 <link rel="stylesheet" href=
              "https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
                  <script src=
              "https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js">
                  </script>
                  <script src=
              "https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js">
                  </script>
                  <script src=
              "https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js">
                  </script>
                <link rel="stylesheet" type="text/css" href="https://bootswatch.com/5/morph/bootstrap.min.css">
   <style>
      .nav-tabs .nav-link
        {
          background-color:#fff;
          color: #081a30;
          border-color: 2px solid black;
        }
       .nav-tabs .nav-link
        {
          background-color:#081a30;
          color:#fff;
          border-color: 2px solid #000;
        }
    </style>
</head>

<body>
  <?php include("header.php");?>

<div class="wrapper">
   <nav id="sidebar">
     <div class="sidebar-header">
      <h4>Side Bar Header</h4>
     </div>
     <ul>
     <li class="active">
       <a href="#home" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle">Home</a>
       <ul class="list-unstyled components" id="home">
         <li>
           <a href="">Home1</a>           
         </li>
          <li>
           <a href="">Home2</a>           
         </li>
       </ul>
     <li>
    </ul>
   </nav>


    <div class="container" style="padding:100px; background-color: #fff;" >
              <ul class="nav nav-tabs" style="margin-top:20px;padding:2px;border:1px solid black;" >
                <li class=" nav-item" style="margin:3px;" ><a class="nav-link active" data-toggle="tab" href="#duty">Attend Shift</a></li>
                <li class="nav-item" style="margin:3px;"><a class="nav-link" data-toggle="tab" href="#history">Shift History</a></li>
                <li class="nav-item" style="margin:3px;"><a class="nav-link" data-toggle="tab" href="#standin">Request StandIn</a></li>
                <li class="nav-item" style="margin:3px;"><a class="nav-link" data-toggle="tab" href="#profile">My Profile</a></li>
              </ul>

              <div class="tab-content">
                <div class="tab-pane active" id="duty">
                <form style="margin-top:20px;width:100%;"  class="justify-content-center">             

              <!-- Email input -->
              <div class="form-group">
                <label for="exampleFormControlSelect1">Duty Category</label>
                <select class="form-control" id="exampleFormControlSelect1">
                  <option>Regular-night</option>
                  <option>Regular-day</option>
                  <option>StandIn-night</option>
                  <option>StandIn-day</option>
                </select>
              </div>

              <!-- Password input -->
              <div class="form-group">
                <label for="exampleFormControlSelect1">Select Station</label>
                <select class="form-control" id="exampleFormControlSelect1">
                  <option>Ongata Rongai</option>
                  <option>Kiserian</option>
                  <option>Ngong</option>
                  <option>Karen</option>
                 </select>
              </div>

              <div class="form-group">
                <label for="exampleFormControlSelect1">Select Client</label>
                <select class="form-control" id="exampleFormControlSelect1">
                  <option>Car Wash</option>
                  <option>Rubis</option>
                  <option>MMU</option>
                 </select>
              </div>

              <div class="form-group">
                <button type="button" class=" form-control btn btn-primary text-white"
                  style="background:#081a30; ">Check In</button>
               
              </div>

            </form>
                </div>          
                        
                <div class="tab-pane" id="history">
                  <h5>My Attendance History</h5>
                  <table class="table table-striped table-dark table-sm table table-hover table-md">
                    <thead>
                      <tr>
                        <th scope="col">#</th>
                        <th scope="col">Station</th>
                        <th scope="col">Client</th>
                        <th scope="col">Date</th>
                        <th scope="col">Verified</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                        <th scope="row">1</th>
                        <td>Kiserian</td>
                        <td>QuickMart</td>
                        <td>04/12/21</td>
                        <td> <div class="custom-control custom-checkbox">
                            <input type="checkbox" class="custom-control-input" id="customCheck1" checked>
                            <label class="custom-control-label" for="customCheck1">Confirm</label>
                          </div>
                       </td>
                      </tr>
                      <tr>
                        <th scope="row">2</th>
                        <td>Rongai</td>
                        <td>Rubis</td>
                        <td>04/12/21</td>
                         <td> <div class="custom-control custom-checkbox">
                            <input type="checkbox" class="custom-control-input" id="customCheck1" checked>
                            <label class="custom-control-label" for="customCheck1">Confirm</label>
                          </div>
                       </td>
                      </tr>
                      <tr>
                        <th scope="row">3</th>
                        <td>Rongai</td>
                        <td>Carwash</td>
                        <td>04/12/21</td>
                         <td> <div class="custom-control custom-checkbox">
                            <input type="checkbox" class="custom-control-input" id="customCheck1" checked>
                            <label class="custom-control-label" for="customCheck1">Confirm</label>
                          </div>
                       </td>
                      </tr>
                    </tbody>
                  </table>          
                </div>

                <div class="tab-pane" id="list" style="padding-top:-200px;">
                <?php include("signup.php");?>
                </div>
              </div>
        
    </div>


</div>
  
















   <script>
   $(".nav-item").on("click",function()
    {
      $(".nav-item").removeClass("active");
      $(this).addClass("active");
    });
   </script>
  <!-- Optional JavaScript -->
    <script src="assets/js/jquery-3.5.1.slim.min.js"></script>
    <script src="assets/js/popper.min.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
    <!-- Custom Js -->
    <script src="./assets/js/app.js"></script>
</body>
</html>

</body>
</html>