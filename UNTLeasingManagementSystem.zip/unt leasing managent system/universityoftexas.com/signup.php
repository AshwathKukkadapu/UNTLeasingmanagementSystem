<?php
  
        // servername => localhost
        // username => root
        // password => empty
        // database name => staff
        $conn = mysqli_connect("localhost", "root", "", "accomodation");
          
        // Check connection
        if($conn === false)
        {
            die("ERROR: Could not connect. " 
                . mysqli_connect_error());
        }
          
        // Taking all 5 values from the form data(input)
        $usertype =  $_POST['usertype'];
        $uname = $_POST['uname'];
        $email =  $_POST['email'];
        $password = $_POST['password'];
      
          
        // Performing insert query execution
        // here our table name is college
        $sql = "INSERT INTO users(user_type,uname,user_email,password)  VALUES ('". $usertype."', 
            '".$uname."','".$email."','". $password."')";
          
        if(mysqli_query($conn, $sql)){

             header("Location:index.html");
            //echo "<h3>data stored in a database successfully." 
               // . " Please browse your localhost php my admin" 
                //. " to view the updated data</h3>"; 
  
            //echo nl2br("\n$first_name\n $last_name\n "
               // . "$gender\n $address\n $email");
        } else{
            echo "ERROR: Hush! Sorry $sql. " 
                . mysqli_error($conn);
        }
          
        // Close connection
        mysqli_close($conn);
        ?>