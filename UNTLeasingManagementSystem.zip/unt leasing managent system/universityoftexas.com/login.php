<?php
header("Location:studentdashboard.php");
/*$servername = "localhost";
$username = "root";
$password = "";
$dbname = "accomodation";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
  die("Connection failed: " . mysqli_connect_error());
}




 
  $usertype=$_POST['usertype'];   
  $uname=$_POST['username'];
  $thepass=$_POST['password'];
  $count=0;
//$sql = "SELECT * FROM admin";
$sql= "SELECT * FROM users WHERE user_type = '".$usertype."' AND uname= '".$uname."' AND password = '".$thepass."'";
$result = mysqli_query($conn,$sql);
$check = mysqli_fetch_array($result);

//echo 'success';
	if($_POST['usertype']=='Student')
	{
  		header("Location:studentdashboard.php");
  	}
  	else if($_POST['usertype']=='Resident')
  	{
  		header("Location:residentdashboard.php");
  	}





//customer login

mysqli_close($conn);*/
?>
