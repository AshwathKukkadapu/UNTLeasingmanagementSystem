<?php 
  $connection = mysqli_connect("localhost", "root", "") or die ("Connection Failed!"); 
    mysqli_select_db($connection, "accomodation");
?>



<!DOCTYPE html>
<html lang="en">


<head>
    <!--<meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">-->

    <!-- Bootstrap CSS -->
    <!--<link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/all.min.css">
    <link rel="stylesheet" href="assets/css/mylogin.css">
    <title>Guards Portal</title>
    -->
      <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">  
                 <link rel="stylesheet" href=
              "https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
                  <script src=
              "https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js">
                  </script>
                  <script src=
              "https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js">
                  </script>
                  <script src=
              "https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js">
                  </script>
                <link rel="stylesheet" type="text/css" href="https://bootswatch.com/5/morph/bootstrap.min.css">
   <style>
      .nav-tabs .nav-link
        {
          background-color:#fff;
          color: #081a30;
          border-color: 2px solid black;
        }
       .nav-tabs .nav-link
        {
          background-color:#081a30;
          color:#fff;
          border-color: 2px solid #000;
        }
    </style>
</head>

<body>
  <?php include("header.php");?>

<div class="wrapper">
   
    <div class="container" style="padding:100px; background-color: #fff;" >
              <ul class="nav nav-tabs" style="margin-top:20px;padding:2px;border:1px solid black;" >
                <li class=" nav-item" style="margin:3px;" ><a class="nav-link active" data-toggle="tab" href="#houses">Houses on Lease</a></li>
                <li class="nav-item" style="margin:3px;"><a class="nav-link" data-toggle="tab" href="#myhouses">Rental History</a></li>
                <li class="nav-item" style="margin:3px;"><a class="nav-link" data-toggle="tab" href="#history">Raise Complaint</a></li>
              </ul>

              <div class="tab-content">
                <div class="tab-pane active" id="houses">
                                  
                <div class="row">
                  <div class="col">
                      <div class="card" style="background:white;margin-top:5px;font-family:Arial Black;">
                        <div class="card-header">Villas </div>
                        <div class="card-body">
                          <div class="row">
                               <div class="col">
                                   <img src="images/villas.jpg" class="img-fluid" style="max-width:100%;height:150px;">
                                </div>
                                 <div class="col">
                                   <u> Amenities</u>
                                    <ul>
                                      <li>Swimming Pool</li>
                                      <li>Washer and dryer</li>
                                    </ul>       
                                </div>
                          </div>
                        </div>
                        <div class="card-footer"><button type="button" class="btn btn-primary btn-sm text-white" style="background:#081a30;">Rent House</button></div>
                      </div>
                  </div>
                  <div class="col">
                      <div class="card" style="background:white;margin-top:5px;font-family:Arial Black;">
                        <div class="card-header">Individual Houses</div>
                        <div class="card-body">
                          <div class="row">
                               <div class="col">
                                   <img src="images/individual.jpg" class="img-fluid" style="max-width:100%;height:150px;">
                                </div>
                                 <div class="col">
                                   <u> Amenities</u>
                                    <ul>
                                      <li>Swimming Pool</li>
                                      <li>Washer and dryer</li>
                                    </ul>       
                                </div>
                          </div>
                        </div>  
                        <div class="card-footer"><button type="button" class="btn btn-primary btn-sm text-white" style="background:#081a30;">Rent House</button></div>
                     </div>

                  </div>                  
                </div>

                </div>          
                        
                <div class="tab-pane" id="history">
                  <form id="login-form" class="form" action="login.php" method="post">
                           
                            
                            <div class="form-group">
                                <label for="password" >Complaint:</label><br>
                                <input type="textarea" name="comp" id="comp" class="form-control">
                            </div>
                            <div class="form-group">
                                     <input type="submit" name="submit" class="btn btn-info btn-md" value="submit" style="background:#081a30; ">
                            </div>
                         </form>
                 </table>

                                
                </div>


                <div class="tab-pane" id="myhouses">
                  <table class="table table-striped table-dark table-sm table table-hover table-md">
                    <thead>
                      <tr>                        
                        <th scope="col">House Id</th>
                        <th scope="col">House Type </th>
                        <th scope="col">Period</th>
                        
                      </tr>
                      <tr>                        
                        <td scope="col">1</th>
                        <td scope="col">Villa</th>
                        <td scope="col">2020-2021</th>

                      </tr>
                    </thead>
                    <tbody>
                 </table>

                                
                </div>

                <div class="tab-pane" id="list" style="padding-top:-200px;">
                <?php include("signup.php");?>
                </div>
              </div>
        
    </div>


</div>
  
















   <script>
   $(".nav-item").on("click",function()
    {
      $(".nav-item").removeClass("active");
      $(this).addClass("active");
    });
   </script>
  <!-- Optional JavaScript -->
    <script src="assets/js/jquery-3.5.1.slim.min.js"></script>
    <script src="assets/js/popper.min.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
    <!-- Custom Js -->
    <script src="./assets/js/app.js"></script>
</body>
</html>

</body>
</html>