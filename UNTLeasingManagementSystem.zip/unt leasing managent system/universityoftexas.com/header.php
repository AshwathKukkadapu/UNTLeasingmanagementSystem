<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/all.min.css">
    <link rel="stylesheet" href="assets/css/login.css">
</head>

<body>
    <!--------------------------------- #Main section -------------------------------->
     <nav class="navbar navbar-inverse navbar-expand-lg  fixed-top" style="background-color:#081a30;color:#fff;margin-bottom:20px;">
        <div class="container-fluid">
            <div class="navbar-header">
               
                <a class="navbar-brand" href="#">
                   <div style="color:#fff;">UNT Leasing Management System</div>
                </a>    
                 <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#mynav">
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>                    
                </button>
            </div>
            <div class="collapse navbar-collapse" id="mynav">
                <!--Links on the navbar-->
                <ul class="navbar-nav ml-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="signup.php" style="color:#fff;"></a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="signup.php" style="color:#fff;"></a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="index.html" style="color:#fff;">Logout</a>
                    </li>
                </ul>
            </div>    
        </div>

         
     </nav>
 
</body>
</html>